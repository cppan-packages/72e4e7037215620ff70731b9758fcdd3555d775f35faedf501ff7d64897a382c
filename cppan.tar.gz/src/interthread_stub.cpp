//Copyright (c) 2015 Emil Dotchevski and Reverge Studios, Inc.

//Distributed under the Boost Software License, Version 1.0. (See accompanying
//file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

namespace
boost
    {
    namespace
    synapse
        {
        namespace
        synapse_detail
            {
            class interthread_interface;
            interthread_interface * get_interthread_api() { return 0; }
            }
        }
    }
