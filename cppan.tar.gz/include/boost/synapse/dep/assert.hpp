//Copyright (c) 2015 Emil Dotchevski and Reverge Studios, Inc.

//Distributed under the Boost Software License, Version 1.0. (See accompanying
//file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef UUID_63C72D4434FB11E68D8B7838C8C3EC59
#define UUID_63C72D4434FB11E68D8B7838C8C3EC59

#ifndef BOOST_SYNAPSE_ASSERT
#include <boost/assert.hpp>
#define BOOST_SYNAPSE_ASSERT BOOST_ASSERT
#endif

#endif
